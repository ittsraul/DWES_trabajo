<?php

namespace app\Core\Interfaces;

interface IRoutes{
    public function getRoutes(): array;
}