<?php

namespace App\Controller;

use App\Entity\Clientes;
use App\Entity\Empresa;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class DetailController extends AbstractController
{
    #[Route('/detail/{parametro?null}', name: 'app_detail')]
    public function index(ManagerRegistry $gestor, string $parametro): Response
    {
        $cliente = $gestor->getManager()->getRepository(CLIENTES::class);
        $clienteEmp = $gestor->getManager()->getRepository(EMPRESA::class);
        $detalleClient = $cliente->findBy(['clienteCod'=> $parametro]);
        $detalleEmp = $clienteEmp->findBy(['EmpNo'=> $parametro]);
        return $this->render('detail.html.twig', [
            'detalleClient' => $detalleClient,
            'detalleEmp' => $detalleEmp
        ]);
    }
}
