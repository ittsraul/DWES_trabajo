<?php

namespace App\Controller;

use App\Entity\Clientes;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Session\SessionInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class ListController extends AbstractController
{
    #[Route('/list/{page}', name: 'app_list')]
    public function index(ManagerRegistry $gestor, $page = null): Response
    {
        $clients = $gestor->getRepository(CLIENTES::class)->findAll();
        return $this->render('clientes.html.twig', [
            'clients' => $clients,
            "page" => $this->getLastPage($page)
        ]);
    }

    private function getLastPage($page)
    {
      if ($page != null) {
        $_SESSION["page"] = $page;
        return $page;
      } elseif (!isset($_SESSION["page"]) || !is_numeric($_SESSION["page"])) {
        $_SESSION["page"] = 1;
        return 1;
      }
      return $_SESSION["page"];
    }

    /*
    private function getLastPage($page)
    {
      if ($page != null) {
        $_SESSION["page"] = $page;
        return $page;
      } elseif (!isst($session->get("page")) || !is_numeric($_SESSION["page"])) {e
        $session->get("page") = 1;
        return 1;
      }
      return $session->"page"];
    }*/
}
