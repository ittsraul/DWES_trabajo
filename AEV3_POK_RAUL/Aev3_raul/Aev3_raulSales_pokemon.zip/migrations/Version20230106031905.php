<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20230106031905 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE CLIENTE (id INT AUTO_INCREMENT NOT NULL, CLIENTE_COD INT NOT NULL, NOMBRE VARCHAR(45) NOT NULL, DIREC VARCHAR(40) NOT NULL, CIUDAD VARCHAR(30) NOT NULL, ESTADO VARCHAR(2) DEFAULT NULL, COD_POSTAL VARCHAR(9) NOT NULL, AREA SMALLINT DEFAULT NULL, TELEFONO VARCHAR(9) DEFAULT NULL, REPR_COD SMALLINT DEFAULT NULL, LIMITE_CREDITO NUMERIC(9, 2) DEFAULT NULL, OBSERVACIONES LONGTEXT DEFAULT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('DROP TABLE CLIENTES');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE CLIENTES (id INT AUTO_INCREMENT NOT NULL, CLIENTE_COD INT NOT NULL, NOMBRE VARCHAR(45) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci`, DIREC VARCHAR(40) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci`, CIUDAD VARCHAR(30) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci`, ESTADO VARCHAR(2) CHARACTER SET utf8mb4 DEFAULT NULL COLLATE `utf8mb4_unicode_ci`, COD_POSTAL VARCHAR(9) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci`, AREA SMALLINT DEFAULT NULL, TELEFONO VARCHAR(9) CHARACTER SET utf8mb4 DEFAULT NULL COLLATE `utf8mb4_unicode_ci`, REPR_COD SMALLINT DEFAULT NULL, LIMITE_CREDITO NUMERIC(9, 2) DEFAULT NULL, OBSERVACIONES LONGTEXT CHARACTER SET utf8mb4 DEFAULT NULL COLLATE `utf8mb4_unicode_ci`, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB COMMENT = \'\' ');
        $this->addSql('DROP TABLE CLIENTE');
    }
}
