<?php

namespace app\Repository;

use Doctrine\ORM\EntityRepository;

class PlayersRepository extends EntityRepository{

}
?>