<?php

namespace app\Repository;

use Doctrine\ORM\EntityRepository;

class EmpRepository extends EntityRepository{

}
