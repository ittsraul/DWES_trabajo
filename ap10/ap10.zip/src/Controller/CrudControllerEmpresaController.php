<?php
namespace App\Controller;

use App\Entity\Clientes;
use App\Entity\Empresa;
use Doctrine\Persistence\ManagerRegistry;
use PhpParser\Builder\Method;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

#[Route('/crud', name: 'app_')]
class CrudController extends AbstractController
{
     #[Route('/insert', name: 'insert', Method: ["POST"])]
    public function index(ManagerRegistry $gestor, Request $request): Response
    {
        $container = $request->request->all();
        if (count($container) > 1) {
             $gestor->getRepository(Clientes::class)->insert($request); 
            return $this->redirect($this->generateUrl("app_list_empresa"));
        } else {
            /* $clients = $gestor->getRepository(Clientes::class)->findAll(); */
            $clients = $gestor->getRepository(Empresa::class)->findAll();
            return $this->render('insert.html.twig', [
                 "clients" => $clients, 
            ]);
        }
    }

    #[Route('/delete/{user}', name: 'delete', method: ["DELETE"])]
    public function delete(ManagerRegistry $gestor, int $user): Response
    {
         $gestor->getRepository(Empresa::class)->delete($user); 
        return $this->redirect($this->generateUrl('app_list_empresa'));
    }

    #[Route('/update/{user}', name: 'update', methods: ["PUT"])]
    public function update(ManagerRegistry $gestor, Request $request, int $user): Response
    {
    $container = $request->request->all();
        if (count($container) > 1) {
             $gestor->getRepository(Empresa::class)->update($request, $user); 
            return $this->redirect($this->generateUrl("app_list_empresa"));
        } else {
            $clients = $gestor->getRepository(Clientes::class)->find($user);
            $emps = $gestor->getRepository(Empresa::class)->findAll();
            return $this->render('update.html.twig', [
                "clients" => $clients,
                "emps" => $emps 
            ]);
        }
    } 
}
