<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

#[Route('/main', name: 'app_')]
class ListController extends AbstractController
{
    #[Route('/list/{parametro?30}', name: 'list')]
    public function index(string $parametro): Response
    {
        return $this->render('list/index.html.twig', [
            'name' => 'ListController',
            'parametro' => $parametro,
        ]);
    }
    #[Route('/detail/{parametro?50}', name: 'detail')]
    public function detail(string $parametro): Response
    {
        return $this->render('list/detail.html.twig', [
            'name' => 'Detail',
            'parametro' => $parametro,
        ]);
    }
}
