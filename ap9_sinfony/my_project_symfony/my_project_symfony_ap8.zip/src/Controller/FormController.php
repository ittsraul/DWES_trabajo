<?php

namespace App\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Session\SessionInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class FormController extends AbstractController
{
    #[Route('/form', name: 'app_form')]
    public function index(Request $request, SessionInterface $session): Response
    {
        if ($request->request->get("name")) {
            $nombre = $request->request->get("name");
            $session->set("nombre_usuario", $nombre);

        }elseif ($session->get("nombre_usuario")) {
            $nombre = $session->get("nombre_usuario");
        }else{
            $nombre="";
        }
        return $this->render('form.html.twig', [
            'controller_name' => 'FormController',
            "nombre" => $nombre
        ]);
    }
}
