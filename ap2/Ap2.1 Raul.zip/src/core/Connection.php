<?php
namespace app\core;

//Tenemos que utilizar use PDO/PDOException porque son funciones nativas de php y no están dentro de estos namespaces
use PDO;
use PDOException;
class Connection
{
    //variable protegida $conn
    protected $conn;
    //funcion conexion a base de datos
    public function connect()
    {
        //ruta que cogerá el fichero de configuracion json.
        $configFile = file_get_contents(__DIR__ ."../config/db.json");
        //json decode passa json a a la variable dbData
        $dbData = json_decode($configFile, true);

        //almacenamos la información de la conexión en variables
        $servername = $dbData["servername"];
        $username = $dbData["username"];
        $password = $dbData["password"];
        $db = $dbData["db"];

        //Establece la conexión
        try {
            $this->conn = new PDO("mysql:host=$servername;dbname=$db", $username, $password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            echo 'Connection has failed: ' . $e->getMessage();
        }
    }

    //desconector con valor nulo
    public function disconnect()
    {
        $this->conn = null;
    }

    //destructor de la conexion llama a el desconector.
    public function __destruct()
    {
        $this->disconnect();
    }
}
