<?php
namespace app\model;
class modelTotal{
    public function getTDetail(){
        //Devolvemos lo que queremos.
    }
}
?>