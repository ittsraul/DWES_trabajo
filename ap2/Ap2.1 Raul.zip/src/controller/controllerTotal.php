<?php
namespace app\controller;

use app\model\modelTotal;
use app\view\viewTotal;
class controllerTotal{
    public function contentList()
    {
        $modelT = new modelTotal();
         $viewT = new viewTotal(); 
        $CurrentList = $modelT->getTDetail();
       $viewT-> drawDetailTotal("Aqui tienes tu lista",$CurrentList); 
    }
}

?>