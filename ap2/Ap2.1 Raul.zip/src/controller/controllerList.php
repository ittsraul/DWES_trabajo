<?php
namespace app\controller;


use app\model\modelList;
use app\view\viewList;

class controllerList
{
    public function contentList()
    {
        $modelL = new modelList();
         $viewL = new viewList(); 
        $CurrentList = $modelL->getMList();
       $viewL-> drawList("Aqui tienes tu lista",$CurrentList); 
    }
}


?>