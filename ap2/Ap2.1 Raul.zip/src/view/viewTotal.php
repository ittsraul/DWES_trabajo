<?php
namespace app\view;

use app\core\Connection;

class viewTotal extends Connection{
    //Para Sacar el detalle, esto dudo de si en modelo o vista
    public function drawDetailTotal($data){
        $client = $this->getTDetail($data);
        if ($client == false) {
            echo "no se encuentra...";
        } else {
            //Duda, donde hago los getters y setters
            $output = "";
            $output .= "<tr><th>Id</th><td>" . $client->getId() . "</td></tr>";
            $output .= "<tr><th>titulo</th><td>" . $client->getTitulo() . "</td></tr>";
            $output .= "<tr><th>Descripcion</th><td>" . $client->getInfo() . " €</td></tr>";
            $output .= "<tr><th>Fecha de Creacion</th><td>" . date("F d, Y", strtotime($client->getDate())) . "</td></tr>";
            $output .= "<tr><th>Fecha de vencimiento</th><td>" . date("F d, Y", strtotime($client->getDateFin())) . "</td></tr>";
        }
    }
}
?>