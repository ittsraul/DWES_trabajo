<?php
namespace app\view;

class viewList{
    public function drawList($data){
        echo "<pre>";
        var_dump($data);
    }
}
?>