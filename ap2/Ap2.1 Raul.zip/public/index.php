<?php

//uso de namespaces
use app\controller\{controllerList,controllerTotal};

//Require del autoloader, el cual esta configurado para buscar en el sitio o a partir del sitio que se le ha indicado
require_once "../vendor/autoload.php";
$accion = $_GET["action"];
$identificador = $_GET["id"];
switch ($accion) {
    case 'detail':
        $controller = new controllerTotal();
        $controller->funcion($identificador - 1);
        break;
    case 'list':
        $controller = new controllerList();
        $controller->contentList();
        break;
}
//Nuevo objeto conexion
//$conex = new Connection();

//llamamos al metodo connect para inciar la conexion
//$conex->connect();
